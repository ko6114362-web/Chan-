package com.chanshop.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1769AA)
private val PaleBlue = Color(0xFFEAF4FF)
private val Ink = Color(0xFF18324A)

data class Product(val id: Int, val name: String, val price: Int, val category: String, val emoji: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChanShopApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChanShopApp() {
    var products by remember {
        mutableStateOf(listOf(
            Product(1, "ချည်သားအင်္ကျီ", 18000, "အင်္ကျီ", "👚"),
            Product(2, "ဒီဇိုင်းလှ စကတ်", 22000, "စကတ်", "👗"),
            Product(3, "Casual Shirt", 25000, "အင်္ကျီ", "👔"),
            Product(4, "နေ့စဉ်ဝတ် ဘောင်းဘီ", 28000, "ဘောင်းဘီ", "👖")
        ))
    }
    val cart = remember { mutableStateMapOf<Int, Int>() }
    var tab by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newPrice by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("အထည်") }
    val cartCount = cart.values.sum()
    val total = products.sumOf { p -> p.price * (cart[p.id] ?: 0) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, onPrimary = Color.White,
            secondary = Color(0xFF5AA4E8), background = Color(0xFFF7FAFE),
            surface = Color.White, onSurface = Ink
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Chan Shop", fontWeight = FontWeight.ExtraBold, color = Blue, fontSize = 22.sp)
                            Text("Fashion & Clothing", fontSize = 11.sp, color = Color.Gray)
                        }
                    },
                    actions = {
                        BadgedBox(badge = { if (cartCount > 0) Badge { Text(cartCount.toString()) } }) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = Blue,
                                modifier = Modifier.padding(end = 16.dp))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Storefront, null) }, label = { Text("ဆိုင်") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.ShoppingBag, null) }, label = { Text("ခြင်း") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Add, null) }, label = { Text("စီမံရန်") })
                }
            },
            containerColor = Color(0xFFF7FAFE)
        ) { padding ->
            when (tab) {
                0 -> ShopScreen(products, cart, Modifier.padding(padding))
                1 -> CartScreen(products, cart, total, Modifier.padding(padding))
                else -> {
                    Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
                        Text("ပစ္စည်းအသစ်ထည့်ရန်", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(newName, { newName = it }, label = { Text("ပစ္စည်းအမည်") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(newPrice, { newPrice = it.filter(Char::isDigit) }, label = { Text("ဈေးနှုန်း (ကျပ်)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(newCategory, { newCategory = it }, label = { Text("အမျိုးအစား") }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = {
                                val price = newPrice.toIntOrNull()
                                if (newName.isNotBlank() && price != null && price > 0) {
                                    products = products + Product((products.maxOfOrNull { it.id } ?: 0) + 1, newName.trim(), price, newCategory, "🛍️")
                                    newName = ""; newPrice = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("ပစ္စည်းထည့်မယ်") }
                        Spacer(Modifier.height(20.dp))
                        Text("တင်ထားသောပစ္စည်း (${products.size})", fontWeight = FontWeight.Bold, color = Ink)
                        products.forEach { p ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("${p.emoji}  ${p.name}", Modifier.weight(1f))
                                Text("${"%,d".format(p.price)} ကျပ်", color = Blue, fontWeight = FontWeight.SemiBold)
                                Text("  ဖျက်", color = Color.Red, modifier = Modifier.clickable {
                                    products = products.filterNot { it.id == p.id }; cart.remove(p.id)
                                })
                            }
                            HorizontalDivider(color = PaleBlue)
                        }
                        Text("မှတ်ချက် - ဒီဗားရှင်းမှာ ပစ္စည်းစာရင်းကို ဖုန်းထဲတွင် ယာယီသိမ်းထားသည်။", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun ShopScreen(products: List<Product>, cart: MutableMap<Int, Int>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().background(PaleBlue).padding(18.dp)) {
            Text("Chan Shop မှ ကြိုဆိုပါတယ်", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Blue)
            Text("သင်နှစ်သက်ရာ အထည်များကို ရွေးချယ်ဝယ်ယူပါ", color = Ink, fontSize = 13.sp)
        }
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(products, key = { it.id }) { p ->
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(72.dp).background(PaleBlue, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            Text(p.emoji, fontSize = 34.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold, color = Ink)
                            Text(p.category, color = Color.Gray, fontSize = 12.sp)
                            Text("${"%,d".format(p.price)} ကျပ်", color = Blue, fontWeight = FontWeight.Bold)
                        }
                        Button(onClick = { cart[p.id] = (cart[p.id] ?: 0) + 1 },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) { Text("ထည့်မယ်") }
                    }
                }
            }
        }
    }
}

@Composable
fun CartScreen(products: List<Product>, cart: MutableMap<Int, Int>, total: Int, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Text("ဝယ်ယူမည့်ပစ္စည်းများ", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(12.dp))
        val selected = products.filter { (cart[it.id] ?: 0) > 0 }
        if (selected.isEmpty()) {
            Text("ဈေးဝယ်ခြင်းထဲတွင် ပစ္စည်းမရှိသေးပါ။", color = Color.Gray)
        } else {
            selected.forEach { p ->
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold)
                        Text("${"%,d".format(p.price)} ကျပ်", color = Blue)
                    }
                    IconButton(onClick = {
                        val q = cart[p.id] ?: 0
                        if (q <= 1) cart.remove(p.id) else cart[p.id] = q - 1
                    }) { Text("−", fontSize = 22.sp) }
                    Text((cart[p.id] ?: 0).toString(), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { cart[p.id] = (cart[p.id] ?: 0) + 1 }) { Text("+", fontSize = 20.sp) }
                }
                HorizontalDivider(color = PaleBlue)
            }
            Spacer(Modifier.height(18.dp))
            Text("စုစုပေါင်း", color = Color.Gray)
            Text("${"%,d".format(total)} ကျပ်", fontSize = 24.sp, color = Blue, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            Spacer(Modifier.height(22.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = PaleBlue)
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("KBZPay ဖြင့် ငွေပေးချေရန်", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Blue)
                    Spacer(Modifier.height(8.dp))
                    Text("အောက်ပါ QR ကို KBZPay ဖြင့် Scan ဖတ်ပြီး ငွေပေးချေပါ။", fontSize = 13.sp, color = Ink)
                    Spacer(Modifier.height(12.dp))
                    Image(
                        painter = painterResource(id = R.drawable.kbzpay_qr),
                        contentDescription = "Chan Shop KBZPay QR",
                        modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp),
                        contentScale = ContentScale.Fit
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("အကောင့်အမည်", fontSize = 12.sp, color = Color.Gray)
                    Text("Daw Khin Soe Win", fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(4.dp))
                    Text("ဖုန်းနံပါတ်", fontSize = 12.sp, color = Color.Gray)
                    Text("09798636215", fontWeight = FontWeight.Bold, color = Ink)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "ငွေလွှဲပြီးပါက ငွေပေးချေမှုအောင်မြင်ကြောင်း KBZPay ထဲတွင် စစ်ဆေးပါ။ ဒီ App ဗားရှင်းမှာ ငွေလွှဲမှုကို အလိုအလျောက် အတည်မပြုနိုင်သေးပါ။",
                        fontSize = 11.sp,
                        color = Color.DarkGray
                    )
                }
            }
        }
    }
}
